enum ImportedWalletType { mnemonic, privateKey }
