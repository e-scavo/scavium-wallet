import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:scavium_wallet/core/config/app_config.dart';
import 'package:scavium_wallet/core/security/screenshot_guard.dart';
import 'package:scavium_wallet/core/utils/evm_address.dart';
import 'package:scavium_wallet/core/utils/evm_amounts.dart';
import 'package:scavium_wallet/features/assets/application/assets_controller.dart';
import 'package:scavium_wallet/features/blockchain/application/native_send_preview_controller.dart';
import 'package:scavium_wallet/features/blockchain/application/send_transaction_controller.dart';
import 'package:scavium_wallet/features/blockchain/presentation/widgets/native_send_confirm_dialog.dart';
import 'package:scavium_wallet/features/wallet/application/wallet_controller.dart';
import 'package:scavium_wallet/shared/widgets/scavium_primary_button.dart';
import 'package:scavium_wallet/shared/widgets/scavium_scaffold.dart';
import 'package:scavium_wallet/shared/widgets/section_title.dart';

class SendScreen extends ConsumerStatefulWidget {
  const SendScreen({super.key});

  @override
  ConsumerState<SendScreen> createState() => _SendScreenState();
}

class _SendScreenState extends ConsumerState<SendScreen> {
  final _toCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  String? _error;

  @override
  void initState() {
    super.initState();
    ScreenshotGuard.enableProtection();
  }

  @override
  void dispose() {
    _toCtrl.dispose();
    _amountCtrl.dispose();
    ScreenshotGuard.disableProtection();
    super.dispose();
  }

  Future<void> _prepareSend() async {
    if (!mounted) return;
    setState(() => _error = null);

    final to = _toCtrl.text.trim();
    final amountText = _amountCtrl.text.trim();

    if (!EvmAddressUtils.isValidAddress(to)) {
      if (!mounted) return;
      setState(() => _error = 'Dirección inválida');
      return;
    }

    if (!EvmAmounts.isPositiveDecimal(amountText)) {
      if (!mounted) return;
      setState(() => _error = 'Monto inválido');
      return;
    }

    if (EvmAmounts.hasTooManyDecimals(amountText, 18)) {
      if (!mounted) return;
      setState(() => _error = 'Demasiados decimales');
      return;
    }

    final currentAddress =
        ref.read(walletControllerProvider).valueOrNull?.account.address;
    if (currentAddress != null &&
        currentAddress.toLowerCase() == to.toLowerCase()) {
      if (!mounted) return;
      setState(() => _error = 'No podés enviarte fondos a vos mismo');
      return;
    }

    final assets = ref.read(assetsControllerProvider).valueOrNull;
    final nativeAsset =
        (assets != null && assets.isNotEmpty) ? assets.first : null;

    final balance = double.tryParse(nativeAsset?.displayBalance ?? '0') ?? 0;
    final amount = double.tryParse(amountText.replaceAll(',', '.')) ?? 0;

    if (amount > balance) {
      if (!mounted) return;
      setState(() => _error = 'Saldo insuficiente');
      return;
    }

    final previewNotifier = ref.read(
      nativeSendPreviewControllerProvider.notifier,
    );

    await previewNotifier.buildPreview(toAddress: to, amountText: amountText);

    if (!mounted) return;

    final previewState = ref.read(nativeSendPreviewControllerProvider);

    if (previewState.hasError) {
      setState(() => _error = previewState.error.toString());
      return;
    }

    final preview = previewState.valueOrNull;
    if (preview == null) return;

    final previewFee =
        double.tryParse(
          (preview.estimatedFeeWei / BigInt.from(1000000000000000000))
              .toString(),
        ) ??
        0;

    if ((amount + previewFee) > balance) {
      setState(() => _error = 'Saldo insuficiente para monto + comisión');
      return;
    }

    await showDialog<void>(
      context: context,
      builder: (context) {
        return NativeSendConfirmDialog(
          preview: preview,
          onConfirm: _sendConfirmed,
        );
      },
    );

    if (!mounted) return;
  }

  Future<void> _sendConfirmed() async {
    final to = _toCtrl.text.trim();
    final amountText = _amountCtrl.text.trim();

    final sendNotifier = ref.read(sendTransactionControllerProvider.notifier);

    await sendNotifier.sendNative(toAddress: to, amountText: amountText);

    if (!mounted) return;

    final state = ref.read(sendTransactionControllerProvider);

    if (state.hasError) {
      setState(() => _error = state.error.toString());
      return;
    }

    final txHash = state.valueOrNull?.txHash;
    if (txHash == null) return;

    await showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Transaction sent'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Your transaction was submitted.'),
              const SizedBox(height: 12),
              SelectableText(txHash),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () async {
                final uri = Uri.parse(
                  '${AppConfig.current.txExplorerPath}/$txHash',
                );
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              },
              child: const Text('Open explorer'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );

    if (!mounted) return;
  }

  @override
  Widget build(BuildContext context) {
    final previewState = ref.watch(nativeSendPreviewControllerProvider);
    final sendState = ref.watch(sendTransactionControllerProvider);

    final isBusy = previewState.isLoading || sendState.isLoading;

    return ScaviumScaffold(
      appBar: AppBar(title: const Text('Send')),
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          SectionTitle(
            title: 'Send ${AppConfig.current.nativeSymbol}',
            subtitle: 'Send native SCAVIUM funds to another EVM address.',
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _toCtrl,
            decoration: InputDecoration(
              labelText: 'Recipient address',
              errorText: _error,
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _amountCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: 'Amount (${AppConfig.current.nativeSymbol})',
            ),
          ),
          const SizedBox(height: 24),
          ScaviumPrimaryButton(
            text: isBusy ? 'Processing...' : 'Continue',
            isLoading: isBusy,
            onPressed: isBusy ? null : _prepareSend,
          ),
        ],
      ),
    );
  }
}
